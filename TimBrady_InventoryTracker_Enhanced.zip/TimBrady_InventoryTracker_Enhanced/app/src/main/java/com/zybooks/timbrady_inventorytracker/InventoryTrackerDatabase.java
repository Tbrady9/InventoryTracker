package com.zybooks.timbrady_inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Database class
public class InventoryTrackerDatabase extends SQLiteOpenHelper {
    private static InventoryTrackerDatabase instance;
    private static final String DATABASE_NAME = "InvTrckrData.db";
    private static final int VERSION = 1;
    static String userRole = "";

    InventoryTrackerDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Declare the database to hold user and item info
    public static InventoryTrackerDatabase getInstance(Context context){
        if (instance == null){
            instance = new InventoryTrackerDatabase(context);
        }
        return instance;
    }

    // Declare the table for items
    private static final class ItemTable{
        private static final String TABLE = "items";
        private static final String ITEM_NAME = "itemName";
        private static final String ITEM_QTY = "qty";
    }

    // Declare the table for users
    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String USER_NAME = "userName";
        private static final String NAME = "name";
        private static final String USER_PASSWORD = "password";
        private static final String USER_ROLE = "userRole";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create item table
        db.execSQL("CREATE TABLE items (" +
                "itemNum INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "itemName text, " +
                "qty text" +
                ")");

        // Create user table
        db.execSQL("CREATE TABLE users (" +
                "userNum INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "userName text, " +
                "name text, " +
                "password text, " +
                "userRole text" +
                ")");
    }

    @Override
    // onUpgrade to upgrade database schema if needed
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + ItemTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE);
        onCreate(db);
    }

    // Add a new item
    public boolean addItem(String itemName, String itemQty) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(ItemTable.ITEM_NAME, itemName);
        cv.put(ItemTable.ITEM_QTY, itemQty);

        long result = db.insert(ItemTable.TABLE, null, cv);
        return result != -1;
    }

    // Add a new user
    public boolean addUser(String userName, String name, String password, String role) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(UserTable.USER_NAME, userName);
        cv.put(UserTable.NAME, name);
        cv.put(UserTable.USER_PASSWORD, password);
        cv.put(UserTable.USER_ROLE, role);

        long result = db.insert(UserTable.TABLE, null, cv);
        return result != -1;
    }

    // Update the quantity of an item in the database
    public boolean updateItem(String itemNum, String itemName, String itemQty){
        boolean itemUpdated = false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(ItemTable.ITEM_NAME, itemName);
        cv.put(ItemTable.ITEM_QTY, itemQty);

        String where = "itemNum = ?";
        String[] whereArgs = new String[]{itemNum};
        System.out.println(itemNum);
        long result = db.update(ItemTable.TABLE, cv, where, whereArgs);
        return result != -1;
    }

    // Update a user
    public boolean updateUser(String userNum, String name, String userRole){
        boolean userUpdated = false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(UserTable.NAME, name);
        cv.put(UserTable.USER_ROLE, userRole);

        String where = "userNum = ?";
        String[] whereArgs = new String[]{userNum};
        long result = db.update(UserTable.TABLE, cv, where, whereArgs);
        return result != -1;
    }

    // Delete an item from the database
    public boolean deleteItem(String itemNum){
        boolean itemDeleted = false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        String where = "itemNum = ?";
        String[] whereArgs = new String[]{itemNum};

        long result = db.delete(ItemTable.TABLE, where, whereArgs);
        return result != -1;
    }

    // Get all data in the items table
    public Cursor getItemData(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from " + ItemTable.TABLE, null);
    }

    // Delete an item from the database
    public boolean deleteUser(String userNum){
        boolean userDeleted = false;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        String where = "userNum = ?";
        String[] whereArgs = new String[]{userNum};

        long result = db.delete(UserTable.TABLE, where, whereArgs);
        return result != -1;
    }

    // Authenticating user login details
    public boolean authenticate( String userName, String userPassword){
        boolean isAuthenticated = false;

        SQLiteDatabase db = getReadableDatabase();

        String sql = " select * from " + UserTable.TABLE +
                " where " + UserTable.USER_NAME + " = ? AND " +
                UserTable.USER_PASSWORD + " = ? ";

        Cursor cursor = db.rawQuery(sql, new String[]{userName, userPassword});

        if (cursor.moveToFirst()) {
            isAuthenticated = true;
            userRole = cursor.getString(4);
        }
        cursor.close();
        return isAuthenticated;
    }

    // Get all data in the user table
    public Cursor getUserData(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from " + UserTable.TABLE, null);
    }

}

