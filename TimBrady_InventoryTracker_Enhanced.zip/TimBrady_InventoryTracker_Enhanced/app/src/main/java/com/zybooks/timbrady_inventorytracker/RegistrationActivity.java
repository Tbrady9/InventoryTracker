package com.zybooks.timbrady_inventorytracker;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class RegistrationActivity extends AppCompatActivity {

    // Variables for text fields and buttons
    EditText name, userName, userPassword, userPasswordConf;
    Button btnSubmit, btnLogin;
    TextView txtViewConfirm;
    InventoryTrackerDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        // Pointing the variables to their matching fields
        userName = findViewById(R.id.editTextUserName);
        name = findViewById(R.id.editTextFirstName);
        userPassword = findViewById(R.id.editTextPassword);
        userPasswordConf = findViewById(R.id.editTextPasswordConf);
        txtViewConfirm = findViewById(R.id.textViewConfirm);
        db = new InventoryTrackerDatabase(this);
        btnSubmit = findViewById(R.id.buttonSubmit);

        // Button to send a user from the registration screen back to the login screen
        // or the users screen depending on how they accessed the registration screen
        btnLogin = findViewById(R.id.buttonBackToLogin);
        if (InventoryTrackerDatabase.userRole.matches("")) {
            btnLogin.setOnClickListener(listener -> loginScreen());
        }
        else {
            btnLogin.setOnClickListener(listener -> DisplayUserScreen());
        }

        // Setting up spinner for employee role dropdown box
        Spinner spinnerRoles = findViewById(R.id.spinnerRole);
        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource(this, R.array.roles,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerRoles.setAdapter(adapter);


        // Clearing confirmation message when any field is selected
        // Name field
        name.setOnFocusChangeListener(new View.OnFocusChangeListener(){

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    txtViewConfirm.setText("");
                }
            }
        });

        // UserName field
        userName.setOnFocusChangeListener(new View.OnFocusChangeListener(){

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus) {
                    txtViewConfirm.setText("");
                }
            }
        });

        // UserPassword field
        userPassword.setOnFocusChangeListener(new View.OnFocusChangeListener(){

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    txtViewConfirm.setText("");
                }
            }
        });

        // UserPasswordConf field
        userPasswordConf.setOnFocusChangeListener(new View.OnFocusChangeListener(){

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    txtViewConfirm.setText("");
                }
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener(){

            // Checks if passwords match and adds user if they do
            @Override
            public void onClick(View v) {
                // If password and password confirmation match, add user
                if (userPassword.getText().toString().equals(userPasswordConf.getText().toString()))
                {
                    String userNameTxt = userName.getText().toString();
                    String nameTxt = name.getText().toString();
                    String userPasswordTxt = userPassword.getText().toString();
                    String userRoleTxt = spinnerRoles.getSelectedItem().toString();

                    // Confirm the user was added
                    Boolean checkAddUser = db.addUser(userNameTxt, nameTxt,
                            userPasswordTxt, userRoleTxt);
                    if (checkAddUser) {
                        txtViewConfirm.setText("User added successfully");
                    } else {
                        txtViewConfirm.setText("Action failed");
                    }
                }
                else {
                    txtViewConfirm.setText("Action Failed");
                }
            }
        });
    }

    // Button functionality for 'Previous Screen' button to go to login screen
    private void loginScreen() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    // Button functionality for 'Previous Screen' button to go to users screen
    private void DisplayUserScreen() {
        Intent intent = new Intent(this, DisplayAllUsersActivity.class);
        startActivity(intent);
    }
}