package com.zybooks.timbrady_inventorytracker;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    private EditText textUserName;
    private EditText textPassword;
    private TextView textViewLoginInvalid;

    @Override
    // onCreate creates the screen when it loads
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Variables for text fields and buttons for the screen
        textUserName = findViewById(R.id.editTextUserName);
        textPassword = findViewById(R.id.editTextPassword);
        textViewLoginInvalid = findViewById(R.id.textViewLoginInvalid);

        // Button to log in
        Button buttonLogin = findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(listener -> confirmLogin());

        // Button to go to the new acct registration screen
        Button buttonCreateAcct = findViewById(R.id.buttonCreateAcct);
        buttonCreateAcct.setOnClickListener(listener -> createAccount());
    }

    // Method to confirm login details
    private void confirmLogin() {
        String userName = textUserName.getText().toString();
        String password = textPassword.getText().toString();

        // Validate user name and password have been registered
        if (InventoryTrackerDatabase.getInstance(getApplicationContext()).authenticate(userName,
                password)) {
            textViewLoginInvalid.setText("");
            Intent intent = new Intent(this, DisplayAllItemsActivity.class);
            startActivity(intent);
        }
        else{
            textViewLoginInvalid.setText("Login credentials invalid");
        }
    }

    // Button functionality to take user to RegistrationActivity to create an account
    private void createAccount() {
        Intent intent = new Intent(this, RegistrationActivity.class);
        startActivity(intent);
    }
}