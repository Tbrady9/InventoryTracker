package com.zybooks.timbrady_inventorytracker;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyUserViewHolder>{
    private Context context;
    private final ArrayList  userNum;
    private final ArrayList userName;
    private final ArrayList name;
    private final ArrayList role;

    // Creating user adapter
    public UserAdapter(Context context, ArrayList userNums, ArrayList userNames, ArrayList names, ArrayList roles) {
        this.context = context;
        this.userNum = userNums;
        this.userName = userNames;
        this.name = names;
        this.role = roles;
    }

    @NonNull
    @Override
    public UserAdapter.MyUserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.user_entry,parent,false);
        return new UserAdapter.MyUserViewHolder(v);
    }

    @Override
    // Creating view holder
    public void onBindViewHolder(@NonNull MyUserViewHolder holderU, int position) {
        // Bind view holder to auto-populate item details on the edit screen (DisplayOneActivity.java)
        holderU.userNum.setText(String.valueOf(userNum.get(position)));
        holderU.userName.setText(String.valueOf(userName.get(position)));
        holderU.name.setText(String.valueOf(name.get(position)));
        holderU.role.setText(String.valueOf(role.get(position)));

        String userNumStr = holderU.userNum.getText().toString();
        String userNameStr = holderU.userName.getText().toString();
        String nameStr = holderU.name.getText().toString();
        String roleStr = holderU.role.getText().toString();

        // Authentication: Ability to edit users only available to manager role
        if (!InventoryTrackerDatabase.userRole.equalsIgnoreCase("manager")) {
            holderU.userButton.setEnabled(false);
        }


        // Navigate to each item's update page and display the item details
        holderU.userButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context, UserDetailActivity.class);
                intent.putExtra("userNumExtra", userNumStr);
                intent.putExtra("userNameExtra", userNameStr);
                intent.putExtra("nameExtra", nameStr);
                intent.putExtra("roleExtra", roleStr);
                context.startActivity(intent);
            }
        });
    }

    @Override
    // Get number of items for iteration and display in recyclerviews
    public int getItemCount() {
        return userNum.size();
    }

    // Assigning text views and buttons
    public class MyUserViewHolder extends RecyclerView.ViewHolder {
        TextView userNum, userName, name, role;
        Button userButton;

        public MyUserViewHolder(@NonNull View userView) {
            super(userView);
            context = userView.getContext();
            userNum = userView.findViewById(R.id.textViewUserNum);
            userName = userView.findViewById(R.id.textViewUserName);
            name = userView.findViewById(R.id.textViewFName);
            role = userView.findViewById(R.id.textViewRole);
            userButton = userView.findViewById(R.id.buttonUpdateEmployee);
        }
    }
}
