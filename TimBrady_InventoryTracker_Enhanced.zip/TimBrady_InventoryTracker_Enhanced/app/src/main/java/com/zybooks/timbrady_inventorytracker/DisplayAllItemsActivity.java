package com.zybooks.timbrady_inventorytracker;

import static com.zybooks.timbrady_inventorytracker.R.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

public class DisplayAllItemsActivity extends AppCompatActivity {

    private InventoryTrackerDatabase db;
    private ArrayList<String> itemNum, itemName, itemQty;
    private TextView textNoItems;
    private final int NOTIFICATION_ID = 0;
    private static final String sharedPrefs = "sharedPrefs";
    private static final String TOGGLEBUTTON = "togglebutton";
    private static final String EDITTEXT = "userLowQty";
    private Boolean toggleOnOff;
    private String lowQty;

    @Override
    // onCreate to create all items on the screen when it is loaded
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_displayall);

        // Button to add an item
        Button buttonAddItem = findViewById(id.buttonAddItem);
        buttonAddItem.setOnClickListener(listener -> addItem());

        // Button to navigate to settings screen
        Button buttonSettings = findViewById(id.buttonSettings);
        buttonSettings.setOnClickListener(listener -> settings());

        // Button to navigate to users screen
        Button buttonUsers = findViewById(id.buttonUsers);
        buttonUsers.setOnClickListener(listener -> userScreen());

        // Declaring variables for text fields as well as arrays to hold item data
        db = new InventoryTrackerDatabase(this);
        itemNum = new ArrayList<>();
        itemName = new ArrayList<>();
        itemQty = new ArrayList<>();
        RecyclerView rv = findViewById(id.recyclerView);
        ItemAdapter adapter = new ItemAdapter(this, itemNum, itemName, itemQty);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(this));
        textNoItems = findViewById(id.textViewNoItems);

        // Display all item data
        displayItemData();

        // Loading preferences for notification settings
        loadData();

        // Shared preferences for notification settings
        SharedPreferences sharedPreferences = getSharedPreferences(sharedPrefs, MODE_PRIVATE);
        toggleOnOff = sharedPreferences.getBoolean(TOGGLEBUTTON, false);

        // Create notification and send if permission granted
        Cursor cursor = db.getItemData();
        if (toggleOnOff) {

            // Send notification if item quantity drops below set number
            for (int i = 0; i < itemQty.size(); i++) {
               if (Integer.parseInt(itemQty.get(i))  <= Integer.parseInt(String.valueOf(lowQty))) {
                   // Setting up notification channel for low qty notifications
                   createItemQtyNotificationChannel();
                   String CHANNEL_ID_QTY = "channel_qty";
                   Notification notification = new NotificationCompat.Builder(
                           DisplayAllItemsActivity.this, CHANNEL_ID_QTY)
                           .setSmallIcon(drawable.cog_wheel)
                           .setContentTitle(getString(string.app_name))
                           .setContentText("Low quantity! Item Name: " + itemName.get(i))
                           .setPriority(NotificationCompat.PRIORITY_HIGH)
                           .build();

                   NotificationManagerCompat notificationManager = NotificationManagerCompat.
                           from(DisplayAllItemsActivity.this);
                   // Post notification using ID
                   notificationManager.notify(NOTIFICATION_ID, notification);
               }
            }
        }

        // Authentication: Ability to add items only available to manager role
        if (!InventoryTrackerDatabase.userRole.equalsIgnoreCase("manager")) {
            buttonAddItem.setEnabled(false);
        }
    }  // End onCreate

    // Start activity to add item
    private void addItem() {
        Intent intent = new Intent(this, AddItemActivity.class);
        startActivity(intent);
    }

    // Start activity to go to settings
    private void settings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    // Start activity to go to user screen
    private void userScreen() {
        Intent intent = new Intent(this, DisplayAllUsersActivity.class);
        startActivity(intent);
    }

    // Displaying items from the item table into a recycler view
    private void displayItemData(){
        Cursor cursor = db.getItemData();

        // Display notification text if no items exist
        if(cursor.getCount()==0){
            textNoItems.setText("No items to display");
        }
        else{
            textNoItems.setText(null);
            while (cursor.moveToNext()){
                itemNum.add(cursor.getString(0));
                itemName.add(cursor.getString(1));
                itemQty.add(cursor.getString(2));
            }
        }
    }

    private final String CHANNEL_ID_QTY = "channel_qty";
    // Create notification channel
    private void createItemQtyNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID_QTY, name, importance);
            channel.setDescription(description);

            // Register channel with system
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    // Loading shared preferences for toggle button state
    public void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences(sharedPrefs, MODE_PRIVATE);
        toggleOnOff = sharedPreferences.getBoolean(TOGGLEBUTTON, false);
        lowQty = sharedPreferences.getString(EDITTEXT, "0");
    }
}