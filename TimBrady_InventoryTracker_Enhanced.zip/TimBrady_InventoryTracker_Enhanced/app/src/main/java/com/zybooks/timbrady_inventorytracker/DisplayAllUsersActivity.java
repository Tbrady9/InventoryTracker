package com.zybooks.timbrady_inventorytracker;

import static com.zybooks.timbrady_inventorytracker.R.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

public class DisplayAllUsersActivity extends AppCompatActivity {
    private InventoryTrackerDatabase db;
    private RecyclerView rv;
    private ArrayList<String> userNum, userName, name, role;
    private UserAdapter adapterU;
    private TextView textNoItems;

    @Override
    // onCreate creates all items on the screen when it is first loaded
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_users);

        // Button functionality to add a user
        Button buttonAddUser = findViewById(id.buttonAddUser);
        buttonAddUser.setOnClickListener(listener -> createAccount());

        // Button functionality to take a user to the item screen
        Button buttonItems = findViewById(id.buttonItems);
        buttonItems.setOnClickListener(listener -> itemScreen());

        // Declaring variables for text fields as well as arrays to hold user data
        db = new InventoryTrackerDatabase(this);
        userNum = new ArrayList<>();
        userName = new ArrayList<>();
        name = new ArrayList<>();
        role = new ArrayList<>();
        rv = findViewById(id.userRecyclerView);
        adapterU = new UserAdapter(this, userNum, userName, name, role);
        rv.setAdapter(adapterU);
        rv.setLayoutManager(new LinearLayoutManager(this));
        textNoItems = findViewById(id.textViewNoUsers);

        // Display all user data
        displayUserData();

        // Authentication: Ability to add users only available to manager role
        if (!InventoryTrackerDatabase.userRole.equalsIgnoreCase("manager")) {
            buttonAddUser.setEnabled(false);
        }
    }  // End onCreate


    // Displaying items from the user table into a recycler view
    private void displayUserData(){
        Cursor cursor = db.getUserData();

        // Display notification text if no items exist
        if(cursor.getCount()==0){
            textNoItems.setText("No users to display");
        }
        else{
            textNoItems.setText(null);
            while (cursor.moveToNext()){
                userNum.add(cursor.getString(0));
                userName.add(cursor.getString(1));
                name.add(cursor.getString(2));
                role.add(cursor.getString(4));
            }
        }
    }

    // Take user to RegistrationActivity to create an account
    private void createAccount() {
        Intent intent = new Intent(this, RegistrationActivity.class);
        startActivity(intent);
    }

    // Take user to item screen
    private void itemScreen() {
        Intent intent = new Intent(this, DisplayAllItemsActivity.class);
        startActivity(intent);
    }

}
